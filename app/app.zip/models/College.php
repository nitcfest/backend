<?php


class College extends Eloquent
{
	protected $table = 'colleges';
	public $timestamps = false;
}