@extends('layouts.user')

@section('title')
Edit Homepage
@stop

@section('head')
@stop

@section('content')

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Edit Homepage</h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-6">
        <h3>Coming soon!</h3>
    </div>
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-8">
    </div>
    <div class="col-lg-4">
    </div>
</div>

@stop

@section('scripts')
@stop