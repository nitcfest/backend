@extends('layouts.user')

@section('title')
Edit Homepage
@stop

@section('head')
@stop

@section('content')

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Unauthorized</h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-6">
        You're not authorized to view this page. If you believe that there's something wrong, contact the administrator.
    </div>
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-8">
    </div>
    <div class="col-lg-4">
    </div>
</div>

@stop

@section('scripts')
@stop